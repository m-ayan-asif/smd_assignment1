package com.ayanasif.i221097;

import static androidx.test.espresso.Espresso.closeSoftKeyboard;
import static androidx.test.espresso.Espresso.onView;
import static androidx.test.espresso.action.ViewActions.click;
import static androidx.test.espresso.action.ViewActions.replaceText;
import static androidx.test.espresso.action.ViewActions.scrollTo;
import static androidx.test.espresso.assertion.ViewAssertions.matches;
import static androidx.test.espresso.matcher.ViewMatchers.isDisplayed;
import static androidx.test.espresso.matcher.ViewMatchers.withEffectiveVisibility;
import static androidx.test.espresso.matcher.ViewMatchers.withId;
import static androidx.test.espresso.matcher.ViewMatchers.withText;

import android.content.Intent;

import androidx.test.core.app.ActivityScenario;
import androidx.test.core.app.ApplicationProvider;
import androidx.test.espresso.matcher.ViewMatchers.Visibility;
import androidx.test.ext.junit.runners.AndroidJUnit4;

import org.junit.Test;
import org.junit.runner.RunWith;

@RunWith(AndroidJUnit4.class)
public class ChatFlowTest {

    /** Typing in the Chats search bar hides rows whose name doesn't match. */
    @Test
    public void chatsSearch_filtersListByName() {
        try (ActivityScenario<ChatsActivity> ignored = ActivityScenario.launch(ChatsActivity.class)) {
            onView(withId(R.id.etSearch)).perform(replaceText("lina"));
            closeSoftKeyboard();

            onView(withId(R.id.c3)).check(matches(isDisplayed()));                       // Lina Marsh
            onView(withId(R.id.c1)).check(matches(withEffectiveVisibility(Visibility.GONE))); // Aisha Khan
            onView(withId(R.id.c4)).check(matches(withEffectiveVisibility(Visibility.GONE))); // Omar Farooq
        }
    }

    /** Sending a message adds an outgoing bubble and clears the input. */
    @Test
    public void chat_sendMessage_appearsInThreadAndClearsInput() {
        Intent intent = new Intent(ApplicationProvider.getApplicationContext(), ChatActivity.class)
                .putExtra("name", "Omar Farooq")
                .putExtra("initials", "OF")
                .putExtra("color", "#2F6E4E");

        try (ActivityScenario<ChatActivity> ignored = ActivityScenario.launch(intent)) {
            onView(withId(R.id.hdrName)).check(matches(withText("Omar Farooq")));

            String msg = "Espresso test message";
            onView(withId(R.id.etMsg)).perform(replaceText(msg));
            closeSoftKeyboard();
            onView(withId(R.id.btnSend)).perform(click());

            onView(withText(msg)).perform(scrollTo()).check(matches(isDisplayed()));
            onView(withId(R.id.etMsg)).check(matches(withText("")));
        }
    }
}
